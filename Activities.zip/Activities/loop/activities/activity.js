// 1.  Use a for loop to iterate through an array of names and log each name.
// 2. Write a while loop that counts from 1 to 10 and logs the numbers.
