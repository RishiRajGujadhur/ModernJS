// Your challenge is to build out the Discord Interface and get it to look as close
// to the design as possible.

// This project focuses on your JS and Bootstrap5 skills

// Your final project should consist of the following functionalities

// Functional Lading page of Discord along with header and footer

// Login and Register Page

// Main Page (Dashboard Page) of Discord

// Add Friends Page
