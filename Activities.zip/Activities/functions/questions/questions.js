// Q1
// Write a function Add that console logs the sum of 2 parameters.
// step 1: Write function Add
// step 2: Add param A and B to the function and log the result
// step 3: call the function Add(1,2)

// Q2
// Write a function expression Substract that console logs parameter A - B.
// step 1: Write function Add
// step 2: Subtract param A and B to the function and log the result
// step 3: call the function Subtract(1,2)

//What is the output of this code?
//Q3
const multiply = (a, b) => a * b;
console.log(multiply(4, 6));

//Q4
function greet(name, callback) {
  console.log(`Hello, ${name}!`);
  callback();
}

function sayGoodbye() {
  console.log("Goodbye!");
}

greet("Alice", sayGoodbye);
