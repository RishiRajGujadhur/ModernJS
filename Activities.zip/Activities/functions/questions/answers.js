//Q1
function add(a, b) {
  let result = a + b;
  console.log(result);
}

//Q2
const substract = function (a, b) {
  let result = a - b;
  console.log(result);
};

//Q3
//24

//Q4
// Hello, Alice!
// Goodbye!
