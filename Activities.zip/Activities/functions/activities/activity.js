//1. Define a function called add that takes two parameters, a and b, and returns their sum.
//2. Write a function called isEven that takes a number as an argument
// and returns true if it's even and false if it's odd.
