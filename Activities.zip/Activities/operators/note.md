Logical Operators (&&, ||, and !)

Inequality Operators (<, >, <=, and >=)

Equality Operators (== and !=):
