//Q1. What is the result of the following expression:
// Q1
//5 > 3

//Q2.
// 5 == "5"

//Q3
// null == undefined.

//Q4
const x = 7;
const y = 7;
console.log(x >= y);
