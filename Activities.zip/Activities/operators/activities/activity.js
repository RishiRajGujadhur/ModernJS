//1. Write a comparison expression that checks if a variable age
// is greater than or equal to 18 and less than 65.

//2.
//  Write a condition using the != operator to check if a variable status is not
// equal to the string "error".

// 3.
// Combine two conditions using the &&
// operator to check if a variable isLogged
// is true and isAdmin is true as well.

// 4.
// Write a condition using the
// || operator to check if a variable
// isGuest is true
// or isMember is true.
