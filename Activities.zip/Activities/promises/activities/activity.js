// Promise Creation: Create a JavaScript promise that resolves after a delay of 2 seconds
// and logs "Promise resolved!" when it resolves.

