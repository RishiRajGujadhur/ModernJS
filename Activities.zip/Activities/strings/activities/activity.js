// 1. Declare a string variable and concatenate it with another string.
// 2. Create a string and convert it to uppercase.
// 3. Write a JavaScript expression that
// concatenates your first name, a space, and your
// last name to form a full name.
// 4.  Explain how template literals
// (backticks) in JavaScript can be used.
// 5. Write a JavaScript expression that combines three strings to create
// the following sentence:
// "Today is a great day."
// 6. Write a JavaScript expression that uses template literals
// to create the following string:
// "The price of the product is Rs 99.99."
