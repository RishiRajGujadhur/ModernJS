//Q1
//991

//Q2
//3

//Q3
//20

//Q4
//'Hello World'

//Q5
// Infinity

//Q6
//Hello Bob
