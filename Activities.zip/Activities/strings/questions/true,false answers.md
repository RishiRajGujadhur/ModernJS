Answer 1: False

// You can extract portions of a string using slicing.
const slicedStr = str.slice(0, 5); // Extract the first 5 characters

Answer 2: False
const upperCase = str.toUpperCase(); // Convert to uppercase but not permanetly

Answer 3: True

Answer 4: False
const subStr = str.substring(0, 10); // Get a substring, (cannot use negative indexes/indices)

Answer 6: True

Answer 7: True

Answer 8: True

Answer 9: True

Answer 10: True

Answer 12: True

Answer 13: True

Answer 14: True

Answer 15: True
