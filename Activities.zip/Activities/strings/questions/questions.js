//What is the output of this code?
//Q1:
console.log(9 + "9" + "1");

//Q2:
console.log("6" - "3");

//Q3
console.log(4 * "5");

//Q4
console.log("Hello" + " " + "World");

//Q5
console.log(10 / 0);

//Q6
const name = "Bob";
const greeting = `Hello, ${name}!`;
