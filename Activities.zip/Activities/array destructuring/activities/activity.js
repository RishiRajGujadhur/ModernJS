// 1. Define an async function called getData
// that simulates fetching data from an API and returns the result as a JSON object.
