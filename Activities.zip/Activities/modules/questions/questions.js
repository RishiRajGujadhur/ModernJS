// Q1
// How do you import and use functions or variables from
//  another module in a JavaScript program?
