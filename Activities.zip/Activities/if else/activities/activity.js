//1. Write an if statement to check if a variable temperature
// is greater than 30 degrees Celsius and log "It's hot!" if true.
//2. Create an if-else statement to determine
// if a number is positive, negative, or zero and log the result.

// Boolean Logic:
// 3. Write an expression using logical operators to check if a user is both
// logged in and has admin privileges.
// 4. Create a condition that checks if a variable is not equal to a certain value.
