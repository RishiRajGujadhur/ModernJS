//What is the output of this code?
// Q1
let num = 10;
if (num > 5) {
  console.log("Number is greater than 5");
} else {
  console.log("Number is not greater than 5");
}

//Q2
let temperature = 25;
if (temperature > 30) {
  console.log("It's hot outside.");
} else if (temperature <= 30 && temperature >= 20) {
  console.log("It's a pleasant day.");
} else {
  console.log("It's cold outside.");
}

//Q3
let isWeekend = true;
if (isWeekend) {
  console.log("It's time to relax.");
} else {
  console.log("Back to work!");
}
