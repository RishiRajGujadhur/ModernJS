//Q1
// Number is greater than 5

//Q2
//It's a pleasant day.

//Q3
//It's time to relax.
