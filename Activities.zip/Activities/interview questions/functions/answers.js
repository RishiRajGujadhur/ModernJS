// Question 1:
"6 5";

// Question 2:
"5";

// Question 3:
"1";

// Question 4:
// The code will output "Index: 4, element: undefined" four times after a delay of 3 seconds each.

// Question 5:
undefined;
// Question 6:
("15");

// Question 7:
("2");

// Question 8:
("32");

// Question 9: foo was called

// Question 10: undefined

// Question 11: 5

// Question 12:
// c
// b
// a

// Question 13: Inner function

// Question 14: Anonymous function

// Question 15: 5

// Question 16: bar

// Question 17: 10

// Question 18: 10
