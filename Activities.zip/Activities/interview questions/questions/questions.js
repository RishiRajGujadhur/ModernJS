// 3 Explain the difference between let, const, and var for variable declaration.

// 7 What is the difference between "null" and "undefined" in JavaScript?

// 8 How does the "this" keyword work in JavaScript?

// 10 Explain the concept of "callback functions" and provide an example of their use.

// Question 10: What is an "arrow function" in JavaScript, and how does it differ from regular functions?

// Question 11: What are "promises" in JavaScript, and how do they work?

// Question 12: What is "asynchronous programming," and how is it achieved in JavaScript?

// Question 14: Explain the difference between "null" and "undefined."

// Question 15: What is the "DOM" in the context of web development and JavaScript?

// Question 16: How do you handle errors in JavaScript, and what are the types of errors you might encounter?

// Question 17: Explain the use of "JSON" in JavaScript and how you can parse and stringify JSON data.
