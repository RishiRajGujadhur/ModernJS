//Q1
//1

//Q2
//undefined

//Q3
//2

//Q4
//Charlie

//Q5
//undefined

//Q6
//3

//Q7
//undefined

//Q8
//["a", "b", "c"]

//Q9
//["Alice", "Bob", "Charlie"]
