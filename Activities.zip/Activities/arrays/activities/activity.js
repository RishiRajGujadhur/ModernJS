//1. Create an array called colors and add three color names to it.
//2. Declare an array numbers with the numbers 1 through 5 in it.
//3. Define a function that accepts an array of numbers and returns the sum of
// all even numbers in the array.
