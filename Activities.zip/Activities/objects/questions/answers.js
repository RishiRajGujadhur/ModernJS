// Question 1: Alice

// Question 2:
// make
// model
// year

// Question 3: ["brand", "price"]

// Question 4: Alice

// Question 5:
// {
//     name: "John",
//     age: 20,
//     address: "123 Main St"
//   }

//   Question 6: 30

// Question 7: true

// Question 8: false

// Question 9: Alice

// Question 10: Samsung
