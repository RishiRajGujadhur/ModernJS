//1. Create an object called person with properties name and age.
//2. Define an object book with properties title, author, and publishedYear.
//3. Explain the purpose of JSON.stringify() and JSON.parse() methods in JavaScript and provide an
// example of each.
//4. Write a JSON object representing a list of products,
// each with properties for name, price, and availability status (true/false).
