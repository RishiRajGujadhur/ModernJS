Question 6: What is the this keyword in JavaScript, and how is its value determined?
Question 8: What is the global object in JavaScript, and how is it related to the this keyword?
Question 9: What is the purpose of the call(), apply(), and bind() methods in JavaScript, and how do they relate to the this keyword?
Question 10: Provide an example of a scenario where the value of this changes within a single function.
