// Event Listener Setup: Write code to add an event listener
// to a button with the ID "myButton"
// that logs "Button clicked!" when the button is clicked.
