// 1. Explain the purpose of the try...catch statement
// in JavaScript and provide an example where it is useful.

// 2.
// Write a JavaScript try...catch statement that attempts to
// parse an invalid JSON string and handles the resulting
// error by logging an error message.
