// Q1
// What happens when an error occurs within the try block,
// and how does it affect the execution of code within the catch block?

// Q2
//When using a try...catch statement, does code execution continue after the
//  catch block if an error is caught?