//Q1
//(Depends on network connectivity) The code fetches and logs data from a URL,
// or logs an error if there's an issue with the network or the response.
