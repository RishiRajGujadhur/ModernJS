//1. Fetch Basics: Write code to make a GET request using the fetch API to retrieve data
// from a specified URL and log the response.
